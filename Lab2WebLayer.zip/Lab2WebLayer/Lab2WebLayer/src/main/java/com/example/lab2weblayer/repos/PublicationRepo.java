package com.example.lab2weblayer.repos;

import com.example.lab2weblayer.model.Publication;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PublicationRepo extends JpaRepository<Publication, Integer> {
}
