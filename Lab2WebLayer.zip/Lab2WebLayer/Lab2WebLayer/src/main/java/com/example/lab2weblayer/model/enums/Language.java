package com.example.lab2weblayer.model.enums;

public enum Language {
    ENGLISH, LITHUANIAN
}
