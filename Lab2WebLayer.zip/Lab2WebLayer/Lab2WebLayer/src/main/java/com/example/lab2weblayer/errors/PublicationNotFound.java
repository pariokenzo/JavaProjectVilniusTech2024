package com.example.lab2weblayer.errors;

public class PublicationNotFound extends RuntimeException {
    public PublicationNotFound(Integer id) {
        super("Could not find publication " + id);
    }
}
