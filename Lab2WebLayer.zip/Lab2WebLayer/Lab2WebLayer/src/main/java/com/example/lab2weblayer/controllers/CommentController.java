package com.example.lab2weblayer.controllers;

import com.example.lab2weblayer.errors.ClientNotFound;
import com.example.lab2weblayer.errors.PublicationNotFound;
import com.example.lab2weblayer.model.*;
import com.example.lab2weblayer.repos.*;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.PublicKey;
import java.util.Optional;
import java.util.Properties;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/comments") // Base path for all user-related endpoints
public class CommentController {


    @Autowired
    private CommentRepo commentRepo;


    @GetMapping("/allComments")
    public Iterable<Comment> getAll() {
        return commentRepo.findAll();
    }
    @GetMapping("/comment/{id}")
    public EntityModel<Comment> getCommentById(@PathVariable Integer id) {
        Comment comment = commentRepo.findById(id)
                .orElseThrow(() -> new PublicationNotFound(id));
        return EntityModel.of(comment,
                linkTo(methodOn(CommentController.class).getCommentById(id)).withSelfRel(),
                linkTo(methodOn(CommentController.class).getAll()).withRel("allComments"));
    }
    @PostMapping("/comment/create")
    public void createComment(@RequestBody Comment comment) {
        commentRepo.save(comment);
    }
    @PatchMapping("/comment/update")
    public ResponseEntity<Comment> updateComment(@RequestBody Comment comment) {
        if (false) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Comment> existingCommentOptional = commentRepo.findById(comment.getId());

        if (!existingCommentOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Comment existingComment = existingCommentOptional.get();
        if (comment.getBody() != null) {
            existingComment.setBody(comment.getBody());
        }
        if (comment.getTitle() != null) {
            existingComment.setTitle(comment.getTitle());
        }
        Comment updatedComment = commentRepo.save(existingComment);
        return ResponseEntity.ok(updatedComment);
    }

    @DeleteMapping("/comment/delete/{id}")
    public void deleteComment(@PathVariable Integer id) {
        commentRepo.deleteById(id);
    }
}