package com.example.lab2weblayer.controllers;

import com.example.lab2weblayer.errors.ClientNotFound;
import com.example.lab2weblayer.errors.PublicationNotFound;
import com.example.lab2weblayer.model.*;
import com.example.lab2weblayer.repos.PeriodicalRepo;
import com.example.lab2weblayer.repos.BookRepo;
import com.example.lab2weblayer.repos.MangaRepo;
import com.example.lab2weblayer.repos.PublicationRepo;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.PublicKey;
import java.util.Optional;
import java.util.Properties;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/publications") // Base path for all user-related endpoints
public class BookController {

    @Autowired
    private PublicationRepo publicationRepo;
    @Autowired
    private PeriodicalRepo periodicalRepo;
    @Autowired
    private MangaRepo mangaRepo;
    @Autowired
    private BookRepo bookRepo;

    @GetMapping("/allPublications")
    public Iterable<Publication> getAll() {
        return publicationRepo.findAll();
    }

    @PostMapping("/book/create")
    public void createBook(@RequestBody Book book) {
        bookRepo.save(book);
    }

    @PostMapping("/periodical/create")
    public void createPeriodical(@RequestBody Periodical periodical) {
        periodicalRepo.save(periodical);
    }

    @PostMapping("/manga/create")
    public void createAdmin(@RequestBody Manga manga) {
        mangaRepo.save(manga);
    }

   @GetMapping("/book/{id}")
    public EntityModel<Book> getBookById(@PathVariable Integer id) {
        Book book = bookRepo.findById(id)
                .orElseThrow(() -> new PublicationNotFound(id));
        return EntityModel.of(book,
                linkTo(methodOn(BookController.class).getBookById(id)).withSelfRel(),
                linkTo(methodOn(BookController.class).getAll()).withRel("allPublications"));
    }
    @GetMapping("/periodical/{id}")
    public EntityModel<Periodical> getPeriodicalById(@PathVariable Integer id) {
        Periodical periodical = periodicalRepo.findById(id)
                .orElseThrow(() -> new PublicationNotFound(id));
        return EntityModel.of(periodical,
                linkTo(methodOn(BookController.class).getPeriodicalById(id)).withSelfRel(),
                linkTo(methodOn(BookController.class).getAll()).withRel("allPublications"));
    }
    @GetMapping("/manga/{id}")
    public EntityModel<Manga> getMangaById(@PathVariable Integer id) {
        Manga manga = mangaRepo.findById(id)
                .orElseThrow(() -> new PublicationNotFound(id));
        return EntityModel.of(manga,
                linkTo(methodOn(BookController.class).getMangaById(id)).withSelfRel(),
                linkTo(methodOn(BookController.class).getAll()).withRel("allPublications"));
    }
    @GetMapping("/publication/{id}")
    public EntityModel<Publication> getPublicationById(@PathVariable Integer id) {
        Publication publication = publicationRepo.findById(id)
                .orElseThrow(() -> new PublicationNotFound(id));
        return EntityModel.of(publication,
                linkTo(methodOn(BookController.class).getPublicationById(id)).withSelfRel(),
                linkTo(methodOn(BookController.class).getAll()).withRel("allPublications"));
    }
    @PatchMapping("/book/update")
    public ResponseEntity<Book> updateBook(@RequestBody Book book) {
        if (false) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Book> existingBookOptional = bookRepo.findById(book.getId());

        if (!existingBookOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Book existingBook = existingBookOptional.get();

        if (book.getAuthor() != null) {
            existingBook.setAuthor(book.getAuthor());
        }
        if (book.getTitle() != null) {
            existingBook.setTitle(book.getTitle());
        }
        if (book.getPublisher() != null) {
            existingBook.setPublisher(book.getPublisher());
        }

        if (book.getGenre() != null) {
            existingBook.setGenre(book.getGenre());
        }
        if (book.getLanguage() != null) {
            existingBook.setLanguage(book.getLanguage());
        }
        if (book.getIsbn() != null) {
            existingBook.setIsbn(book.getIsbn());
        }

        if (book.getFormat() != null) {
            existingBook.setFormat(book.getFormat());
        }

        if (book.getSummary() != null) {
            existingBook.setSummary(book.getSummary());
        }
        Book updatedBook = bookRepo.save(existingBook);


        return ResponseEntity.ok(updatedBook);
    }

    @PatchMapping("/periodical/update")
    public ResponseEntity<Periodical> updatePeriodical(@RequestBody Periodical periodical) {
        if (false) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Periodical> existingPeriodicalOptional = periodicalRepo.findById(periodical.getId());

        if (!existingPeriodicalOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Periodical existingPeriodical = existingPeriodicalOptional.get();

        if (periodical.getAuthor() != null) {
            existingPeriodical.setAuthor(periodical.getAuthor());
        }
        if (periodical.getTitle() != null) {
            existingPeriodical.setTitle(periodical.getTitle());
        }
        if (periodical.getPublisher() != null) {
            existingPeriodical.setPublisher(periodical.getPublisher());
        }

        if (periodical.getPublicationDate() != null) {
            existingPeriodical.setPublicationDate(periodical.getPublicationDate());
        }
        if (periodical.getEditor() != null) {
            existingPeriodical.setEditor(periodical.getEditor());
        }

        if (periodical.getFrequency() != null) {
            existingPeriodical.setFrequency(periodical.getFrequency());
        }
        Periodical updatedPeriodical = periodicalRepo.save(existingPeriodical);
        return ResponseEntity.ok(updatedPeriodical);
    }
    @PatchMapping("/manga/update")
    public ResponseEntity<Manga> updateManga(@RequestBody Manga manga) {
        if (false) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Manga> existingMangaOptional = mangaRepo.findById(manga.getId());

        if (!existingMangaOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Manga existingManga = existingMangaOptional.get();
        if (manga.getAuthor() != null) {
            existingManga.setAuthor(manga.getAuthor());
        }
        if (manga.getTitle() != null) {
            existingManga.setTitle(manga.getTitle());
        }
        if (manga.getDemographic() != null) {
            existingManga.setDemographic(manga.getDemographic());
        }
        if (manga.getIllustrator() != null) {
            existingManga.setIllustrator(manga.getIllustrator());
        }
     Manga updatedManga = mangaRepo.save(existingManga);
        return ResponseEntity.ok(updatedManga);
    }


    @DeleteMapping("/book/delete/{id}")
    public String deleteBook(@PathVariable int id) {
        bookRepo.deleteById(id);
        return "Book deleted successfully";
    }
    @DeleteMapping("/periodical/delete/{id}")
    public String deletePeriodical(@PathVariable int id) {
        periodicalRepo.deleteById(id);
        return "Periodical deleted successfully";
    }
    @DeleteMapping("/manga/delete/{id}")
    public String deleteManga(@PathVariable int id) {
        mangaRepo.deleteById(id);
        return "Manga deleted successfully";
    }
    @DeleteMapping("/publication/delete/{id}")
    public String deletePublication(@PathVariable int id) {
        publicationRepo.deleteById(id);
        return "Publication deleted successfully";
    }
}
