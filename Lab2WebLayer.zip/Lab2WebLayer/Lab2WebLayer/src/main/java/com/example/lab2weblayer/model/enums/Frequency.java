package com.example.lab2weblayer.model.enums;

public enum Frequency {
}
