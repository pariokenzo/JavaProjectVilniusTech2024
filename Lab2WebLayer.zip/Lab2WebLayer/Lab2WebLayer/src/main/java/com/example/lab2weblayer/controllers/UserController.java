package com.example.lab2weblayer.controllers;

import com.example.lab2weblayer.errors.ClientNotFound;
import com.example.lab2weblayer.model.Admin;
import com.example.lab2weblayer.model.Client;
import com.example.lab2weblayer.model.User;
import com.example.lab2weblayer.repos.AdminRepo;
import com.example.lab2weblayer.repos.ClientRepo;
import com.example.lab2weblayer.repos.UserRepo;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.Properties;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/users") // Base path for all user-related endpoints
public class UserController {

    @Autowired
    private UserRepo userRepo;
    @Autowired
    private ClientRepo clientRepo;
    @Autowired
    private AdminRepo adminRepo;

    @GetMapping("/allUsers")
    public Iterable<User> getAllUsers() {
        return userRepo.findAll();
    }
    @GetMapping("/allClients")
    public Iterable<Client> getAllClients() {
        return clientRepo.findAll();
    }

    @PostMapping("/client/create")
    public void createClient(@RequestBody Client client) {
        clientRepo.save(client);
    }

    @PostMapping("/admin/create")
    public void createAdmin(@RequestBody Admin admin) {
        adminRepo.save(admin);
    }

    @GetMapping("/client/{id}")
    public EntityModel<Client> getClientById(@PathVariable Integer id) {
        Client client = clientRepo.findById(id)
                .orElseThrow(() -> new ClientNotFound(id));
        return EntityModel.of(client,
                linkTo(methodOn(UserController.class).getClientById(id)).withSelfRel(),
                linkTo(methodOn(UserController.class).getAllUsers()).withRel("allUsers"));
    }

    @GetMapping("/admin/{id}")
    public EntityModel<Admin> getAdminById(@PathVariable Integer id) {
        Admin admin = adminRepo.findById(id)
                .orElseThrow(() -> new ClientNotFound(id));
        return EntityModel.of(admin,
                linkTo(methodOn(UserController.class).getAdminById(id)).withSelfRel(),
                linkTo(methodOn(UserController.class).getAllUsers()).withRel("allUsers"));
    }

    @DeleteMapping("/client/delete/{id}")
    public String deleteClient(@PathVariable int id) {
        clientRepo.deleteById(id);
        return "Client deleted successfully";
    }

    @DeleteMapping("/admin/delete/{id}")
    public String deleteAdmin(@PathVariable int id) {
        adminRepo.deleteById(id);
        return "Admin deleted successfully";
    }

    @PostMapping(value = "validateClient")
    public Client validateClient(@RequestBody String loginInfo) {
        //Sioje vietoje man reik parsint jei bus string, tam naudoju Gson biblioteka

        Gson gson = new Gson();
        Properties properties = gson.fromJson(loginInfo,Properties.class);
        String login = properties.getProperty("login");
        String psw = properties.getProperty("psw");

        Client client = clientRepo.getClientByLoginAndPassword(login, psw);
        if (client != null) {
            return client;
        } else {
            return null;
        }
    }

    @PostMapping(value = "validateAdmin")
    public Admin validateAdmin(@RequestBody String loginInfo) {
        //Sioje vietoje man reik parsint jei bus string, tam naudoju Gson biblioteka

        Gson gson = new Gson();
        Properties properties = gson.fromJson(loginInfo,Properties.class);
        String login = properties.getProperty("login");
        String psw = properties.getProperty("psw");

        Admin admin = adminRepo.getAdminByLoginAndPassword(login, psw);
        if (admin != null) {
            return admin;
        } else {
            return null;
        }
    }

    @PatchMapping("/client/update")
    public ResponseEntity<Client> updateClient(@RequestBody Client client) {
        if (false) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Client> existingClientOptional = clientRepo.findById(client.getId());

        if (!existingClientOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Client existingClient = existingClientOptional.get();

        if (client.getName() != null) {
            existingClient.setName(client.getName());
        }
       if (client.getSurname() != null) {
            existingClient.setSurname(client.getSurname());
        }
        if (client.getLogin() != null) {
            existingClient.setLogin(client.getLogin());
        }
        if (client.getPassword() != null) {
            existingClient.setPassword(client.getPassword());
        }

        Client updatedClient = clientRepo.save(existingClient);

        return ResponseEntity.ok(updatedClient);
    }

    @PatchMapping("/admin/update")
    public ResponseEntity<Admin> updateAdmin(@RequestBody Admin admin) {
        if (false) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Admin> existingAdminOptional = adminRepo.findById(admin.getId());

        if (!existingAdminOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Admin existingAdmin = existingAdminOptional.get();
        if (admin.getName() != null) {
            existingAdmin.setName(admin.getName());
        }
        if (admin.getSurname() != null) {
            existingAdmin.setSurname(admin.getSurname());
        }
        if (admin.getLogin() != null) {
            existingAdmin.setLogin(admin.getLogin());
        }
        if (admin.getPassword() != null) {
            existingAdmin.setPassword(admin.getPassword());
        }
        if (admin.getPhoneNum() != null) {
            existingAdmin.setPhoneNum(admin.getPhoneNum());
        }
        Admin updatedAdmin = adminRepo.save(existingAdmin);

        return ResponseEntity.ok(updatedAdmin);
    }
}
