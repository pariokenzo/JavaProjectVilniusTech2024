package com.example.lab2weblayer.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.lab2weblayer.model.Admin;
public interface AdminRepo extends JpaRepository<Admin, Integer> {
    Admin getAdminByLoginAndPassword(String login, String password);
}
