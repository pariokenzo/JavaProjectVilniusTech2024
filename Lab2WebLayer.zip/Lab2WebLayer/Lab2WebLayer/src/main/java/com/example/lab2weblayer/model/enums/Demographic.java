package com.example.lab2weblayer.model.enums;

public enum Demographic {
    //TODO complete during the 3rd lecture
}
