package com.example.lab2weblayer.repos;

import com.example.lab2weblayer.model.Manga;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MangaRepo extends JpaRepository<Manga, Integer> {
}
