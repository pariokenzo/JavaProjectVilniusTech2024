package com.example.lab2weblayer.model.enums;

public enum PublicationStatus {
    AVAILABLE, PENDING, RESERVED, SOLD, REQUESTED, UNAVAILABLE
}
