package com.example.lab2weblayer.repos;

import com.example.lab2weblayer.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentRepo extends JpaRepository<Comment, Integer> {
}
