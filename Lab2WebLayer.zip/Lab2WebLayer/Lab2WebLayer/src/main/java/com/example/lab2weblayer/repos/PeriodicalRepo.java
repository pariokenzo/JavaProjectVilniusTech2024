package com.example.lab2weblayer.repos;

import com.example.lab2weblayer.model.Periodical;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PeriodicalRepo extends JpaRepository<Periodical,Integer> {

}
